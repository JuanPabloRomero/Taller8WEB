function printMessage() {
  console.log('submitted');
}
